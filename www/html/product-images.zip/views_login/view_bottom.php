 <script src="/js/validator.js"></script>
 <!--<script src="/js/togglers.js"></script> -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>

 </body>

 </html>